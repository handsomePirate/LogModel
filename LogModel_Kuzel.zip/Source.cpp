#include "LogProblem.hpp"
#include "AStarInterface.hpp"
#include "AStarSolver.hpp"
#include <iostream>

int main(int argv, char* argc[])
{
	LogProblem problem(argc[1]);
	AStarSolver solver;
	std::vector<std::unique_ptr<IAction>> solution;
	int cost = solver.Solve(problem, solution);
	std::cout << std::endl << "===========SOLUTION===========" << std::endl << std::endl;
	LogProblem::OutputSolution(std::cout, solution);
	std::cout << std::endl << "-- cost: " << cost << std::endl;

	return 0;
}